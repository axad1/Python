import sys

sys.path.insert(0, "../src")

import cs50

i = cs50.get_int("Input:  ")
print(f"Output: {i}")
